import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mbt-testing',
  templateUrl: './mbt-testing.component.html',
  styleUrls: ['./mbt-testing.component.css']
})
export class MbtTestingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
