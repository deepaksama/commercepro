package com.ancestry.commercepro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommerceproApplicationTests {

	@Test
	void contextLoads() {
	}

}
