package com.ancestry.commercepro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommerceproApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommerceproApplication.class, args);
	}

}
